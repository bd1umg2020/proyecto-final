-- --------------------------------------------------------------------------------
-- 
-- ORACLE Application Express (APEX) source export file
-- 
-- The contents of this file are intended for review and analysis purposes only.
-- Developers must use the Application Builder to make modifications to an
-- application. Changes to this file will not be reflected in the application.
-- 
-- --------------------------------------------------------------------------------

-- ----------------------------------------
-- Page 10020: Apariencia de la aplicación
-- Elemento de Página: P10020_END_USER_STYLE
-- Consulta SQL

select ui.theme_style_by_user_pref
  from apex_application_themes t, apex_appl_user_interfaces ui
 where ui.application_id = t.application_id
   and ui.theme_number   = t.theme_number
   and t.application_id  = :app_id 
   and t.ui_type_name    = 'DESKTOP'
   and t.is_current      = 'Yes'

-- ----------------------------------------
-- Page 10020: Apariencia de la aplicación
-- Proceso: Guardar preferencia de estilo de usuario final
-- Código PL/SQL

declare
    l_enabled boolean := case when :P10020_END_USER_STYLE = 'Yes' then true else false end;
begin
    for c1 in ( select ui.theme_number
                from apex_application_themes t,
                    apex_appl_user_interfaces ui
                where ui.application_id = t.application_id
                    and ui.theme_number   = t.theme_number
                    and t.application_id  = :APP_ID
                    and t.ui_type_name    = 'DESKTOP'
                    and t.is_current      = 'Yes' ) loop
        if l_enabled then
            apex_theme.enable_user_style (
                p_application_id => :APP_ID,
                p_theme_number   => c1.theme_number );
        else
            apex_theme.disable_user_style (
                p_application_id => :APP_ID,
                p_theme_number   => c1.theme_number );
            apex_theme.clear_all_users_style(:APP_ID);
        end if;
  end loop;
end;

-- ----------------------------------------
-- Page 10020: Apariencia de la aplicación
-- Proceso: Guardar estilo de tema
-- Código PL/SQL

if :P10020_DESKTOP_THEME_STYLE_ID is not null then
    for c1 in (select theme_number
               from apex_application_themes
               where application_id = :app_id
               and ui_type_name   = 'DESKTOP'
               and is_current = 'Yes')
    loop
        apex_util.set_current_theme_style (
            p_theme_number   => c1.theme_number,
            p_theme_style_id => :P10020_DESKTOP_THEME_STYLE_ID
            );
    end loop;
end if;

-- ----------------------------------------
-- Page 10020: Apariencia de la aplicación
-- Elemento de Página: P10020_DESKTOP_THEME_STYLE_ID
-- Consulta SQL

select null
from apex_application_theme_styles s,
    apex_application_themes t
where s.application_id = t.application_id
    and s.theme_number = t.theme_number
    and s.application_id = :app_id
    and t.ui_type_name   = 'DESKTOP'

-- ----------------------------------------
-- Page 10020: Apariencia de la aplicación
-- Elemento de Página: P10020_DESKTOP_THEME_STYLE_ID
-- Consulta SQL

select s.theme_style_id
from apex_application_theme_styles s,
    apex_application_themes t
where s.application_id = t.application_id
    and s.theme_number = t.theme_number
    and s.application_id = :app_id
    and t.ui_type_name   = 'DESKTOP'
    and s.is_current = 'Yes'

