-- --------------------------------------------------------------------------------
-- 
-- ORACLE Application Express (APEX) source export file
-- 
-- The contents of this file are intended for review and analysis purposes only.
-- Developers must use the Application Builder to make modifications to an
-- application. Changes to this file will not be reflected in the application.
-- 
-- --------------------------------------------------------------------------------

-- ----------------------------------------
-- Page 10050: Comentarios
-- Elemento de Página: P10050_USER_AGENT
-- Consulta SQL

select sys.owa_util.get_cgi_env('user-agent') x
from dual

-- ----------------------------------------
-- Page 10050: Comentarios
-- Proceso: Enviar Comentarios
-- Código PL/SQL

begin
apex_util.submit_feedback (
    p_comment              => :P10050_FEEDBACK,
    p_application_id       => :APP_ID,
    p_page_id              => :P10050_PAGE_ID,
    p_rating               => :P10050_RATING

 );
end;

-- ----------------------------------------
-- Page 10050: Comentarios
-- Validación: Se necesita al menos un comentario
-- Cuerpo de la Función PL/SQL

if :P10050_FEEDBACK is null and :P10050_RATING is null then
    return false;
else
    return true;
end if;

