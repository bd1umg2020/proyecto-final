-- --------------------------------------------------------------------------------
-- 
-- ORACLE Application Express (APEX) source export file
-- 
-- The contents of this file are intended for review and analysis purposes only.
-- Developers must use the Application Builder to make modifications to an
-- application. Changes to this file will not be reflected in the application.
-- 
-- --------------------------------------------------------------------------------

-- ----------------------------------------
-- Page 10061: Ayuda
-- Región: Búsqueda
-- Código PL/SQL

for c1 in 
(
    select page_title, help_text 
      from apex_application_pages
     where page_id = :P10061_PAGE_ID 
       and application_id = :APP_ID
)
loop
    if c1.help_text is null then
        sys.htp.p('No hay ayuda disponible para esta página.');
    else
        if substr(c1.help_text, 1, 3) != '<p>' then
            sys.htp.p('<p>');
        end if;

        sys.htp.p(apex_application.do_substitutions(c1.help_text));

        if substr(trim(c1.help_text), -4) != '</p>' then
            sys.htp.p('</p>');
        end if;
    end if;
end loop;

