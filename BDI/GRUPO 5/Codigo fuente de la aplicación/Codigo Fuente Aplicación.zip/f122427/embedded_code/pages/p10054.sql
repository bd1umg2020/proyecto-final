-- --------------------------------------------------------------------------------
-- 
-- ORACLE Application Express (APEX) source export file
-- 
-- The contents of this file are intended for review and analysis purposes only.
-- Developers must use the Application Builder to make modifications to an
-- application. Changes to this file will not be reflected in the application.
-- 
-- --------------------------------------------------------------------------------

-- ----------------------------------------
-- Page 10054: Comentarios
-- Proceso: Cargar Datos
-- Código PL/SQL

for c1 in (
   select page_id,
          page_name,
          case feedback_rating
                when 1 then '<span class="fa fa-frown-o feedback-negative" aria-hidden="true" title="Negativa"></span>' 
                when 2 then '<span class="fa fa-emoji-neutral feedback-neutral" aria-hidden="true" title="Normal"></span>'  
                when 3 then '<span class="fa fa-smile-o feedback-positive" aria-hidden="true" title="Positiva"></span>' 
                end rating_icon,
          lower(created_by) || ' - ' || apex_util.get_since(created_on) filed,
          feedback,
          public_response,
          feedback_status,
          http_user_agent
     from apex_team_feedback
    where feedback_id = :P10054_ID
) loop
   :P10054_PAGE_ID := c1.page_id||'. '||c1.page_name;
   :P10054_FILED := c1.filed;
   :P10054_RATING_ICON := c1.rating_icon;
   :P10054_FEEDBACK := c1.feedback;
   :P10054_RESPONSE := c1.public_response;
   :P10054_FEEDBACK_STATUS := c1.feedback_status;
   :P10054_USER_AGENT := c1.http_user_agent;
end loop;

-- ----------------------------------------
-- Page 10054: Comentarios
-- Proceso: Suprimir
-- Código PL/SQL

apex_util.delete_feedback (
    p_feedback_id        => :P10054_ID );

-- ----------------------------------------
-- Page 10054: Comentarios
-- Proceso: Actualizar
-- Código PL/SQL

apex_util.reply_to_feedback (
    p_feedback_id        => :P10054_ID,
    p_status             => :P10054_FEEDBACK_STATUS,
    p_public_response    => :P10054_RESPONSE );

