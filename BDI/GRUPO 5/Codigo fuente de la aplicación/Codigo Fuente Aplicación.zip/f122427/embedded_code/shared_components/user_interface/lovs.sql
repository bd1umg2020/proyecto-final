-- --------------------------------------------------------------------------------
-- 
-- ORACLE Application Express (APEX) source export file
-- 
-- The contents of this file are intended for review and analysis purposes only.
-- Developers must use the Application Builder to make modifications to an
-- application. Changes to this file will not be reflected in the application.
-- 
-- --------------------------------------------------------------------------------

-- ----------------------------------------
-- Shared Component
-- Lista de Valores: ACCESS_ROLES
-- Consulta SQL

select role_name d, role_id r
from APEX_APPL_ACL_ROLES where application_id = :APP_ID 
order by 1

-- ----------------------------------------
-- Shared Component
-- Lista de Valores: CLIENTE.
-- Consulta SQL

select p.id_persona, p.nombre, c.id_cliente
from cliente c
inner join persona p on c.id_persona= p.id_persona;

-- ----------------------------------------
-- Shared Component
-- Lista de Valores: DESKTOP THEME STYLES
-- Consulta SQL

select s.name d,
    s.theme_style_id r
from apex_application_theme_styles s, apex_application_themes t
where s.application_id = t.application_id
    and s.theme_number = t.theme_number
    and s.application_id = :app_id
    and t.ui_type_name   = 'DESKTOP'
    and t.is_current = 'Yes'
order by 1

-- ----------------------------------------
-- Shared Component
-- Lista de Valores: TIMEFRAME (4 WEEKS)
-- Consulta SQL

select disp,
      val as seconds
 from table( apex_util.get_timeframe_lov_data )
order by insert_order

