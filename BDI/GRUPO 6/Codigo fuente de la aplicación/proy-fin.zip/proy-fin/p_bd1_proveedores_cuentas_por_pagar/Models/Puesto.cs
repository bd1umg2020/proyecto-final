﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_bd1_proveedores_cuentas_por_pagar.Models
{
    public class Puesto
    {
        public int ID_PUESTO { get; set; }
        public string NOMBRE_PUESTO { get; set; }
    }
}
