﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_bd1_proveedores_cuentas_por_pagar.Models.Reportes
{
    public class facturaProveedor_
    {
        public int NUMERO_FACTURA { get; set; }
        public string NOMBRE_PROVEEDOR { get; set; }
        public string NIT_PROVEEDOR { get; set; }
        public int ID_ORDEN_COMPRA { get; set; }
        public DateTime FECHA_FACTURA { get; set; }
        public double MONTO { get; set; }
    }
}
