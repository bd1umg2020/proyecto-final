﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_bd1_proveedores_cuentas_por_pagar.Models.Reportes
{
    public class estadoCuentaBanco
    {
        public int ID_PAGAR_CUENTA { get; set; }
        public double MONTO { get; set; }
        public string NOMBRE_FORMA_PAGO { get; set; }
        public double SALDO_ANTERIOR { get; set; }
        public double SALDO_NUEVO { get; set; }
        public int NO_CUENTA { get; set; }
        public string NOMBRE_BANCO { get; set; }
    }
}
