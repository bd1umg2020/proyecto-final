﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_bd1_proveedores_cuentas_por_pagar.Models.Reportes
{
    public class compraProducto
    {
        public string NOMBRE_PRODUCTO { get; set; }
        public int CANTIDAD { get; set; }
    }
}
