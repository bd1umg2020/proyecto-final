﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_bd1_proveedores_cuentas_por_pagar.Models
{
    public class Cuenta_banco
    {
        public int ID_CUENTA_BANCO { get; set; }
        public int ID_TIPO_CUENTA { get; set; }
        public int ID_BANCO { get; set; }
        public int NO_CUENTA { get; set; }
        public double SALDO { get; set; }
    }
}
