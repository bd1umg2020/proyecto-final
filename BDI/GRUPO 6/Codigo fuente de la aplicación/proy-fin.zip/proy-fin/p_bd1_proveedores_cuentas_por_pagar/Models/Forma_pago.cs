﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_bd1_proveedores_cuentas_por_pagar.Models
{
    public class Forma_pago
    {
        public int ID_FORMA_PAGO { get; set; }
        public string NOMBRE_FORMA_PAGO { get; set; }
    }
}
