﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_bd1_proveedores_cuentas_por_pagar.Models.Roles
{
    public class Usuario
    {
        public int ID_USUARIO { get; set; }
        public string NOMBRE { get; set; }
        public string CLAVE { get; set; }
    }
}
