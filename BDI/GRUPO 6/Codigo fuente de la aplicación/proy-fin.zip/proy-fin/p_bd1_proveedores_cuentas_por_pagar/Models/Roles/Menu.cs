﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_bd1_proveedores_cuentas_por_pagar.Models.Roles
{
    public class Menu
    {
        public int ID_MENU { get; set; }
        public int NIVEL { get; set; }
        public string NOMBRE { get; set; }
        public int ID_MENU_SUPERIOR { get; set; }
    }
}
