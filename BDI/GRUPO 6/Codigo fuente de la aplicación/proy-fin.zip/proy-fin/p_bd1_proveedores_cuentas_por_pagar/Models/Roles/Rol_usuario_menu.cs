﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_bd1_proveedores_cuentas_por_pagar.Models.Roles
{
    public class Rol_usuario_menu
    {
        public int ID_ROL_USUARIO_MENU { get; set; }
        public int ID_ROL_USUARIO { get; set; }
        public int ID_MENU { get; set; }
        public string NOMBRE_ROL_USUARIO { get; set; }
        public string NOMBRE_MENU { get; set; }
    }
}
