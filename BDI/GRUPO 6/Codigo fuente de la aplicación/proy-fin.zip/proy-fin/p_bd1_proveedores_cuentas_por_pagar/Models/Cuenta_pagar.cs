﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_bd1_proveedores_cuentas_por_pagar.Models
{
    public class Cuenta_pagar
    {
        public int ID_CUENTA_PAGAR { get; set; }
        public int ID_FACTURA_PROVEEDOR { get; set; }
        public int NUMERO_FACTURA { get; set; }
        public DateTime FECHA_FACTURA { get; set; }
        public double MONTO { get; set; }
    }
}
