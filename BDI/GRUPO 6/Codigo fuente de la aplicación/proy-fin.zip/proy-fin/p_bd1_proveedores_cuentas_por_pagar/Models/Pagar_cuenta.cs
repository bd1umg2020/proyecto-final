﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_bd1_proveedores_cuentas_por_pagar.Models
{
    public class Pagar_cuenta
    {
        public int ID_PAGAR_CUENTA { get; set; }
        public int ID_FORMA_PAGO { get; set; }
        public int ID_CUENTA_PAGAR { get; set; }
        public int ID_CUENTA_BANCO { get; set; }
        public double MONTO { get; set; }
        public int NUMERO_DOCUMENTO { get; set; }
        public DateTime FECHA { get; set; }
    }
}
