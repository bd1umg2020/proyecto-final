﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_bd1_proveedores_cuentas_por_pagar.Models
{
    public class Tipo_proveedor
    {
        public int ID_TIPO_PROVEEDOR { get; set; }
        public string NOMBRE_TIPO_PROVEEDOR { get; set; }
    }
}
