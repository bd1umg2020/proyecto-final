﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_bd1_proveedores_cuentas_por_pagar.Models
{
    public class Sucursal
    {
        public int ID_SUCURSAL { get; set; }
        public int ID_DIRECCION { get; set; }
        public int ID_TIPO_SUCURSAL { get; set; }
        public string NOMBRE_SUCURSAL { get; set; }
    }
}
