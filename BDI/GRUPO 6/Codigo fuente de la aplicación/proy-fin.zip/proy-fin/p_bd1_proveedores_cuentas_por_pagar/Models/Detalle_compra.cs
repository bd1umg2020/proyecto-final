﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_bd1_proveedores_cuentas_por_pagar.Models
{
    public class Detalle_compra
    {
        public int ID_DETALLE_COMPRA { get; set; }
        public int ID_ORDEN_COMPRA { get; set; }
        public int ID_PRODUCTO { get; set; }
        public double CANTIDAD { get; set; }
        public double PRECIO { get; set; }
    }
}
