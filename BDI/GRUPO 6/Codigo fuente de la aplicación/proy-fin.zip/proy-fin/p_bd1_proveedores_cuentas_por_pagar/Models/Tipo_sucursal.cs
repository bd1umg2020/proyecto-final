﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_bd1_proveedores_cuentas_por_pagar.Models
{
    public class Tipo_sucursal
    {
        public int ID_TIPO_SUCURSAL { get; set; }
        public string NOMBRE_TIPO_SUCURSAL { get; set; }
    }
}
