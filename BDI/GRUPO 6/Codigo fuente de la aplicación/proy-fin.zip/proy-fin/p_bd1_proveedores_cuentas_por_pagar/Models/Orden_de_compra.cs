﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace p_bd1_proveedores_cuentas_por_pagar.Models
{
    public class Orden_de_compra
    {
        public int ID_ORDEN_COMPRA { get; set; }
        public int ID_PROVEEDOR { get; set; }
        public int ID_PUESTO_EMPLEADO { get; set; }
        public DateTime FECHA { get; set; }
        public string STATUS_APROBACION { get; set; }
        public string STATUS_RECEPCION { get; set; }
    }
}
