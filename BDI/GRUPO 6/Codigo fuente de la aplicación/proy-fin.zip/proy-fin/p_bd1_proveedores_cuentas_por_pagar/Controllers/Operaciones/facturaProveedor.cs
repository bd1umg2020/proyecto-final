﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using p_bd1_proveedores_cuentas_por_pagar.Models;

namespace p_bd1_proveedores_cuentas_por_pagar.Controllers.Operaciones
{
    public class facturaProveedor : Controller
    {
        // GET: facturaProveedor
        public ActionResult Index()
        {
            List<Factura_proveedor> lista_factura_proveedor = new List<Factura_proveedor>();
            var sql = "SELECT * FROM FACTURA_PROVEEDOR ORDER BY FECHA";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                Factura_proveedor mi_factura_proveedor = new Factura_proveedor();
                mi_factura_proveedor.ID_FACTURA_PROVEEDOR = Convert.ToInt32(dr["ID_FACTURA_PROVEEDOR"]);
                mi_factura_proveedor.ID_SERVICIO = (dr["ID_SERVICIO"] != DBNull.Value?Convert.ToInt32(dr["ID_SERVICIO"]):0);
                mi_factura_proveedor.ID_ORDEN_COMPRA = (dr["ID_ORDEN_COMPRA"]!= DBNull.Value ? Convert.ToInt32(dr["ID_ORDEN_COMPRA"]):0);
                mi_factura_proveedor.NUMERO_FACTURA = Convert.ToInt32(dr["NUMERO_FACTURA"]);
                mi_factura_proveedor.FECHA = Convert.ToDateTime(dr["FECHA"]);
                mi_factura_proveedor.MONTO = Convert.ToDouble(dr["MONTO"]);
                lista_factura_proveedor.Add(mi_factura_proveedor);
            }

            dr.Dispose();
            return View(lista_factura_proveedor);
        }


        // GET: facturaProveedor/Create
        public ActionResult Create()
        {
            var orden_compra = new List<SelectListItem>();
            var sql = "SELECT * FROM ORDEN_COMPRA WHERE STATUS_APROBACION = 'S'";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                orden_compra.Add(new SelectListItem()
                {
                    Text = dr["ID_ORDEN_COMPRA"].ToString(),
                    Value = dr["ID_ORDEN_COMPRA"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.orden_compra = orden_compra;


            return View();
        }

        // POST: facturaProveedor/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                var id_servicio = collection["id_servicio"];
                var id_orden_compra = collection["id_orden_compra"];
                var numero_factura = collection["numero_factura"];
                var fecha = collection["fecha"];
                var monto = collection["monto"];
                var sql = $"INSERT INTO FACTURA_PROVEEDOR (ID_FACTURA_PROVEEDOR, ID_SERVICIO, ID_ORDEN_COMPRA, NUMERO_FACTURA, FECHA, MONTO) " +
                    $"VALUES ((SELECT NVL(MAX(ID_FACTURA_PROVEEDOR),0) + 1 FROM FACTURA_PROVEEDOR),'{id_servicio}','{id_orden_compra}','{numero_factura.ToString().ToUpper().Trim()}','{fecha.ToString().ToUpper().Trim()}'," +
                    $"'{monto.ToString().ToUpper().Trim()}')";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }

      
    }
}
