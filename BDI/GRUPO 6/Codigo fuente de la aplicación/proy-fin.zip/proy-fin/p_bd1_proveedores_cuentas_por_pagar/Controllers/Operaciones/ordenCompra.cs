﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using p_bd1_proveedores_cuentas_por_pagar.Models;

namespace p_bd1_proveedores_cuentas_por_pagar.Controllers.Operaciones
{
    public class ordenCompra : Controller
    {
        // GET: ordenCompra
        public ActionResult Index()
        {
            return View();
        }



        // GET: ordenCompra/Create
        public ActionResult Create()
        {
            var proveedor = new List<SelectListItem>();
            var sql = "SELECT * FROM PROVEEDOR ORDER BY NOMBRE_PROVEEDOR";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                proveedor.Add(new SelectListItem()
                {
                    Text = dr["NOMBRE_PROVEEDOR"].ToString(),
                    Value = dr["ID_PROVEEDOR"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.proveedor = proveedor;
            var puesto_empleado = new List<SelectListItem>();
            sql = "SELECT * FROM PUESTO_EMPLEADO A INNER JOIN EMPLEADO B ON A.ID_EMPLEADO = B.ID_EMPLEADO INNER JOIN PERSONA C ON C.ID_PERSONA = B.ID_PERSONA ORDER BY NOMBRE_PERSONA";
            dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                puesto_empleado.Add(new SelectListItem()
                {
                    Text = dr["NOMBRE_PERSONA"].ToString(),
                    Value = dr["ID_PUESTO_EMPLEADO"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.puesto_empleado = puesto_empleado;

            var producto = new List<SelectListItem>();
            sql = "SELECT * FROM PRODUCTO ORDER BY NOMBRE_PRODUCTO";
            dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                producto.Add(new SelectListItem()
                {
                    Text = dr["NOMBRE_PRODUCTO"].ToString(),
                    Value = dr["ID_PRODUCTO"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.producto = producto;



            return View();
        }

        // POST: ordenCompra/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                List<Detalle_compra> lista_detalle_compra = HttpContext.Session.GetComplexData<List<Detalle_compra>>("prod-orden-compra");
                if (lista_detalle_compra == null)
                {
                    throw new Exception("No ha agregado productos");
                }
                if (lista_detalle_compra.Count == 0)
                {
                    throw new Exception("No ha agregado productos");
                }
                var id_proveedor = collection["id_proveedor"];
                var id_puesto_empleado = collection["id_puesto_empleado"];
                var fecha = Convert.ToDateTime(collection["fecha"]).ToString("dd/MM/yyyy");
                var status_aprobacion = collection["status_aprobacion"];
                var status_recepcion = collection["status_recepcion"];

                var sql = $"INSERT INTO ORDEN_COMPRA (ID_ORDEN_COMPRA, ID_PROVEEDOR, ID_PUESTO_EMPLEADO, FECHA, STATUS_APROBACION, STATUS_RECEPCION) VALUES (" +
                    $"(SELECT NVL(MAX(ID_ORDEN_COMPRA),0) + 1 FROM ORDEN_COMPRA), '{id_proveedor}','{id_puesto_empleado}','{fecha}','N','N')";
                ora_conn.ExecuteNonQuery(sql);

                foreach (Detalle_compra item in lista_detalle_compra)
                {
                     sql = $"INSERT INTO DETALLE_COMPRA (ID_DETALLE_COMPRA, ID_ORDEN_COMPRA, ID_PRODUCTO, CANTIDAD, PRECIO) VALUES (" +
                  $"(SELECT NVL(MAX(ID_DETALLE_COMPRA),0) + 1 FROM DETALLE_COMPRA), (SELECT NVL(MAX(ID_ORDEN_COMPRA),0) FROM ORDEN_COMPRA),'{item.ID_PRODUCTO}','{item.CANTIDAD}','{item.PRECIO}')";
                    ora_conn.ExecuteNonQuery(sql);
                }
                return RedirectToAction("compras","menu");
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return RedirectToAction("compras","menu");
            }
        }


        public void agregarProducto(int idProducto, double cantidad, double precio)
        {
            Detalle_compra mi_detalle_compra = new Detalle_compra();
            mi_detalle_compra.ID_PRODUCTO = idProducto;
            mi_detalle_compra.CANTIDAD = cantidad;
            mi_detalle_compra.PRECIO = precio;

            if (HttpContext.Session.GetComplexData<List<Detalle_compra>>("prod-orden-compra") == null)
            {
                List<Detalle_compra> lista_detalle_compra = new List<Detalle_compra>();
                lista_detalle_compra.Add(mi_detalle_compra);
                HttpContext.Session.SetComplexData("prod-orden-compra", lista_detalle_compra);
            }
            else
            {
                List<Detalle_compra> lista_detalle_compra = HttpContext.Session.GetComplexData<List<Detalle_compra>>("prod-orden-compra");
                if (lista_detalle_compra.Any(x => x.ID_PRODUCTO == idProducto))
                {
                    lista_detalle_compra.Where(x => x.ID_PRODUCTO == idProducto).First().CANTIDAD += mi_detalle_compra.CANTIDAD;
                }
                else
                {
                    lista_detalle_compra.Add(mi_detalle_compra);
                }
                HttpContext.Session.SetComplexData("prod-orden-compra", lista_detalle_compra);
            }

        }

        public ActionResult devolverProductos()
        {
            List<Detalle_compra> lista_detalle_compra = new List<Detalle_compra>();
            if (HttpContext.Session.GetComplexData<List<Detalle_compra>>("prod-orden-compra") != null)
            {
                lista_detalle_compra = HttpContext.Session.GetComplexData<List<Detalle_compra>>("prod-orden-compra");
                
            }
            return View(lista_detalle_compra);
        }
    }
}
