﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using p_bd1_proveedores_cuentas_por_pagar.Models;

namespace p_bd1_proveedores_cuentas_por_pagar.Controllers.Operaciones
{
    public class cuentaPagarController : Controller
    {
        // GET: cuentaPagarController
        public ActionResult Index()
        {
            List<Cuenta_pagar> lista_cuenta_pagar = new List<Cuenta_pagar>();
            var sql = "SELECT * FROM CUENTA_PAGAR A INNER JOIN FACTURA_PROVEEDOR B ON A.ID_FACTURA_PROVEEDOR = B.ID_FACTURA_PROVEEDOR ORDER BY ID_CUENTA_PAGAR";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                Cuenta_pagar mi_cuenta_pagar = new Cuenta_pagar();
                mi_cuenta_pagar.ID_CUENTA_PAGAR = Convert.ToInt32(dr["ID_CUENTA_PAGAR"]);
                mi_cuenta_pagar.ID_FACTURA_PROVEEDOR = Convert.ToInt32(dr["ID_FACTURA_PROVEEDOR"]);
                mi_cuenta_pagar.NUMERO_FACTURA = Convert.ToInt32(dr["NUMERO_FACTURA"]);
                mi_cuenta_pagar.FECHA_FACTURA = Convert.ToDateTime(dr["FECHA"]);
                mi_cuenta_pagar.MONTO = Convert.ToDouble(dr["MONTO"]);
                lista_cuenta_pagar.Add(mi_cuenta_pagar);
            }
            dr.Dispose();
            return View(lista_cuenta_pagar);
        }


        public ActionResult pagarCuenta(int id)
        {
            var forma_pago = new List<SelectListItem>();
            var sql = "SELECT * FROM FORMA_PAGO ORDER BY NOMBRE_FORMA_PAGO";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                forma_pago.Add(new SelectListItem()
                {
                    Text = dr["NOMBRE_FORMA_PAGO"].ToString(),
                    Value = dr["ID_FORMA_PAGO"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.forma_pago = forma_pago;

            var cuenta_banco = new List<SelectListItem>();
            sql = "SELECT * FROM CUENTA_BANCO A INNER JOIN BANCO B ON A.ID_BANCO = B.ID_BANCO ORDER BY NO_CUENTA ";
            dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                cuenta_banco.Add(new SelectListItem()
                {
                    Text = $"{dr["NOMBRE_BANCO"].ToString()} - {dr["NO_CUENTA"].ToString()}",
                    Value = dr["ID_CUENTA_BANCO"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.cuenta_banco = cuenta_banco;
            ViewBag.idCuenta = id;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult pagarCuenta(IFormCollection collection)
        {
            try
            {
                var id_forma_pago = collection["id_forma_pago"];
                var id_cuenta_pagar = collection["id_cuenta_pagar"];
                var id_cuenta_banco = collection["id_cuenta_banco"];
                var monto = collection["monto"];
                var numero_documento = collection["numero_documento"];
                var fecha = Convert.ToDateTime(collection["fecha"]).ToString("dd/MM/yyyy");
                var sql = $"INSERT INTO PAGAR_CUENTA (ID_PAGAR_CUENTA, ID_FORMA_PAGO, ID_CUENTA_PAGAR, ID_CUENTA_BANCO, MONTO, NUMERO_DOCUMENTO, FECHA) " +
                    $"VALUES ((SELECT NVL(MAX(ID_PAGAR_CUENTA),0) + 1 FROM PAGAR_CUENTA),'{id_forma_pago}','{id_cuenta_pagar}','{id_cuenta_banco}','{monto}','{numero_documento}','{fecha}')";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }


        // GET: pagos
        public ActionResult pagos()
        {
            List<Pagar_cuenta> listar_pagar_cuenta = new List<Pagar_cuenta>();
            var sql = "SELECT * FROM PAGAR_CUENTA ORDER BY ID_CUENTA_PAGAR ";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                Pagar_cuenta mi_pagar_cuenta = new Pagar_cuenta();
                mi_pagar_cuenta.ID_PAGAR_CUENTA = Convert.ToInt32(dr["ID_PAGAR_CUENTA"]);
                mi_pagar_cuenta.ID_FORMA_PAGO = Convert.ToInt32(dr["ID_FORMA_PAGO"]);
                mi_pagar_cuenta.ID_CUENTA_PAGAR = Convert.ToInt32(dr["ID_CUENTA_PAGAR"]);
                mi_pagar_cuenta.ID_CUENTA_BANCO = Convert.ToInt32(dr["ID_CUENTA_BANCO"]);
                mi_pagar_cuenta.MONTO = Convert.ToDouble(dr["MONTO"]);
                mi_pagar_cuenta.NUMERO_DOCUMENTO = Convert.ToInt32(dr["NUMERO_DOCUMENTO"]);
                mi_pagar_cuenta.FECHA = Convert.ToDateTime(dr["FECHA"]);

                listar_pagar_cuenta.Add(mi_pagar_cuenta);
            }
            dr.Dispose();
            return View(listar_pagar_cuenta);
        }

    }
}
