﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using p_bd1_proveedores_cuentas_por_pagar.Models;

namespace p_bd1_proveedores_cuentas_por_pagar.Controllers
{
    public class proveedorController : Controller
    {
        // GET: proveedorController
        public ActionResult Index()
        {
            List<Proveedor> lista_proveedores = new List<Proveedor>();
            var sql = "SELECT * FROM PROVEEDOR ORDER BY NOMBRE_PROVEEDOR";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                Proveedor mi_proveedor = new Proveedor();
                mi_proveedor.ID_PROVEEDOR = Convert.ToInt32(dr["ID_PROVEEDOR"]);
                mi_proveedor.ID_TIPO_PROVEEDOR = Convert.ToInt32(dr["ID_TIPO_PROVEEDOR"]);
                mi_proveedor.ID_DIRECCION = Convert.ToInt32(dr["ID_DIRECCION"]);
                mi_proveedor.NOMBRE_PROVEEDOR = dr["NOMBRE_PROVEEDOR"].ToString();
                mi_proveedor.NIT_PROVEEDOR = dr["NIT_PROVEEDOR"].ToString();
                lista_proveedores.Add(mi_proveedor);
                      }

            dr.Dispose();
            return View(lista_proveedores);
        }
      

        // GET: proveedorController/Create
        public ActionResult Create()
        {
            var tipo_proveedor = new List<SelectListItem>();
            var sql = "SELECT * FROM TIPO_PROVEEDOR ORDER BY NOMBRE_TIPO_PROVEEDOR";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                tipo_proveedor.Add(new SelectListItem()
                {
                    Text = dr["NOMBRE_TIPO_PROVEEDOR"].ToString(),
                    Value = dr["ID_TIPO_PROVEEDOR"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.tipo_proveedor = tipo_proveedor;

            var direccion = new List<SelectListItem>();
            sql = "SELECT * FROM DIRECCION ORDER BY DIRECCION";
            dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                direccion.Add(new SelectListItem()
                {
                    Text = dr["DIRECCION"].ToString(),
                    Value = dr["ID_DIRECCION"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.direccion = direccion;

            return View();
        }

        // POST: proveedorController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                var id_direccion = collection["id_direccion"];
                var id_tipo_proveedor = collection["id_tipo_proveedor"];
                var nombre = collection["nombre_proveedor"];
                var nit = collection["nit_proveedor"];
                var sql = $"INSERT INTO PROVEEDOR (ID_PROVEEDOR, ID_TIPO_PROVEEDOR, ID_DIRECCION, NOMBRE_PROVEEDOR, NIT_PROVEEDOR) VALUES ((SELECT NVL(MAX(ID_PROVEEDOR),0) + 1 FROM PROVEEDOR)," +
                    $"'{id_tipo_proveedor}','{id_direccion}','{nombre}','{nit}')";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch(Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }

        // GET: proveedorController/Edit/5
        public ActionResult Edit(int id)
        {
            Proveedor mi_proveedor = new Proveedor();
            var sql = $"SELECT * FROM PROVEEDOR WHERE ID_PROVEEDOR = {id}";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                mi_proveedor.ID_PROVEEDOR = Convert.ToInt32(dr["ID_PROVEEDOR"]);
                mi_proveedor.ID_DIRECCION = Convert.ToInt32(dr["ID_DIRECCION"]);
                mi_proveedor.ID_TIPO_PROVEEDOR = Convert.ToInt32(dr["ID_TIPO_PROVEEDOR"]);
                mi_proveedor.NOMBRE_PROVEEDOR = dr["NOMBRE_PROVEEDOR"].ToString();
                mi_proveedor.NIT_PROVEEDOR = dr["NIT_PROVEEDOR"].ToString();
            }
            dr.Dispose();

            var tipo_proveedor = new List<SelectListItem>();
            sql = "SELECT * FROM TIPO_PROVEEDOR ORDER BY NOMBRE_TIPO_PROVEEDOR";
            dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                tipo_proveedor.Add(new SelectListItem()
                {
                    Text = dr["NOMBRE_TIPO_PROVEEDOR"].ToString(),
                    Value = dr["ID_TIPO_PROVEEDOR"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.tipo_proveedor = tipo_proveedor;

            var direccion = new List<SelectListItem>();
            sql = "SELECT * FROM DIRECCION ORDER BY DIRECCION";
            dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                direccion.Add(new SelectListItem()
                {
                    Text = dr["DIRECCION"].ToString(),
                    Value = dr["ID_DIRECCION"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.direccion = direccion;


            return View(mi_proveedor);
        }

        // POST: proveedorController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                var id_proveedor = collection["id_proveedor"];
                var id_tipo_proveedor = collection["id_tipo_proveedor"];
                var id_direccion = collection["id_direccion"];
                var nombre_proveedor = collection["nombre_proveedor"];
                var nit_proveedor = collection["nit_proveedor"];
                var sql = $"UPDATE PROVEEDOR SET  ID_TIPO_PROVEEDOR = '{id_tipo_proveedor}', ID_DIRECCION='{id_direccion}', NOMBRE_PROVEEDOR='{nombre_proveedor}', NIT_PROVEEDOR='{nit_proveedor}' " +
                    $" WHERE ID_PROVEEDOR = '{id}'";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }

        // GET: proveedorController/Delete/5
        public ActionResult Delete(int id)
        {
            Proveedor mi_proveedor = new Proveedor();
            var sql = $"SELECT * FROM PROVEEDOR WHERE ID_PROVEEDOR = {id}";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                mi_proveedor.ID_PROVEEDOR = Convert.ToInt32(dr["ID_PROVEEDOR"]);
                mi_proveedor.ID_DIRECCION = Convert.ToInt32(dr["ID_DIRECCION"]);
                mi_proveedor.ID_TIPO_PROVEEDOR = Convert.ToInt32(dr["ID_TIPO_PROVEEDOR"]);
                mi_proveedor.NOMBRE_PROVEEDOR = dr["NOMBRE_PROVEEDOR"].ToString();
                mi_proveedor.NIT_PROVEEDOR = dr["NIT_PROVEEDOR"].ToString();
            }
            dr.Dispose();
            return View(mi_proveedor);
        }

        // POST: proveedorController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                var sql = $"DELETE FROM PROVEEDOR WHERE ID_PROVEEDOR = '{id}'";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }


        public ActionResult CrearContacto()
        {
            return View();
        }
        public ActionResult EliminarContacto()
        {
            return View();
        }
    }
}
