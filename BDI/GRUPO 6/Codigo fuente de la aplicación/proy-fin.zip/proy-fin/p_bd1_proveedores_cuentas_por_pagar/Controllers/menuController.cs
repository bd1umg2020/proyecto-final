﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace p_bd1_proveedores_cuentas_por_pagar.Controllers
{
    public class menuController : Controller
    {
        public IActionResult Catalogos()
        {
            return View();
        }

        public IActionResult Bodega()
        {
            return View();
        }

        public IActionResult Compras()
        {
            return View();
        }

        public IActionResult Contabilidad()
        {
            return View();
        }
    }
}
