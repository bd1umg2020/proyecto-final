﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using p_bd1_proveedores_cuentas_por_pagar.Models.Roles;

namespace p_bd1_proveedores_cuentas_por_pagar.Controllers.Roles
{
    public class menu2Controller : Controller
    {
        // GET: menuController
        public ActionResult Index()
        {
            List<Menu> lista_menu = new List<Menu>();
            var sql = "SELECT * FROM MENU ORDER BY NIVEL, ID_MENU";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                Menu mi_menu = new Menu();
                mi_menu.ID_MENU = Convert.ToInt32(dr["ID_MENU"]);
                mi_menu.NOMBRE = dr["NOMBRE"].ToString();
                mi_menu.NIVEL = Convert.ToInt32(dr["NIVEL"]);

                lista_menu.Add(mi_menu);
            }

            dr.Dispose();
            return View(lista_menu);
        }


        // GET: menuController/Create
        public ActionResult Create()
        {
            var menu = new List<SelectListItem>();
            var sql = "SELECT * FROM MENU WHERE NIVEL = '0'";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                menu.Add(new SelectListItem()
                {
                    Text = dr["NOMBRE"].ToString(),
                    Value = dr["ID_MENU"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.menu = menu;
            return View();
        }

        // POST: menuController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {

                var nommbre = collection["nombre"];
                var nivel = collection["nivel"];
                var id_menu_superior = collection["id_menu_superior"];
                if (nivel == "0")
                {
                    var sql = $"INSERT INTO MENU (ID_MENU, NOMBRE, NIVEL, ID_MENU_SUPERIOR" +
                     $") VALUES ((SELECT NVL(MAX(ID_MENU),0) + 1 FROM MENU),'{nommbre}','{nivel}',NULL)";
                    ora_conn.ExecuteNonQuery(sql);
                    return RedirectToAction(nameof(Index));
                }
                else
                {
                    var sql = $"INSERT INTO MENU (ID_MENU, NOMBRE, NIVEL, ID_MENU_SUPERIOR" +
                    $") VALUES ((SELECT NVL(MAX(ID_MENU),0) + 1 FROM MENU),'{nommbre}','{nivel}','{id_menu_superior}')";
                    ora_conn.ExecuteNonQuery(sql);
                    return RedirectToAction(nameof(Index));
                }

            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }

      

        // GET: menuController/Delete/5
        public ActionResult Delete(int id)
        {
            Menu mi_menu = new Menu();
            var sql = $"SELECT * FROM MENU WHERE ID_MENU = {id}";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                mi_menu.ID_MENU = Convert.ToInt32(dr["ID_MENU"]);
                mi_menu.NOMBRE = dr["NOMBRE"].ToString();
            }
            dr.Dispose();
            return View(mi_menu);
        }

        // POST: menuController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                var sql = $"DELETE FROM MENU WHERE ID_MENU = '{id}'";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }
    }
}
