﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using p_bd1_proveedores_cuentas_por_pagar.Models.Roles;

namespace p_bd1_proveedores_cuentas_por_pagar.Controllers.Roles
{
    public class rolUsuarioMenuController : Controller
    {
        // GET: rolUsuarioMenuController
        public ActionResult Index()
        {
            List<Rol_usuario_menu> lista_rol_usuario_menu = new List<Rol_usuario_menu>();
            var sql = "SELECT A.ID_ROL_USUARIO_MENU, A.ID_MENU, A.ID_ROL_USUARIO, B.NOMBRE NOMBRE_MENU, D.NOMBRE NOMBRE_ROL, E.NOMBRE NOMBRE_USUARIO FROM ROL_USUARIO_MENU A INNER JOIN MENU B ON A.ID_MENU = B.ID_MENU INNER JOIN ROL_USUARIO C ON C.ID_ROL_USUARIO = A.ID_ROL_USUARIO" +
                " INNER JOIN ROL2 D ON D.ID_ROL2 = C.ID_ROL2 INNER JOIN USUARIO E ON E.ID_USUARIO = C.ID_USUARIO  ORDER BY A.ID_ROL_USUARIO_MENU";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                Rol_usuario_menu mi_rol_usuario_menu = new Rol_usuario_menu();
                mi_rol_usuario_menu.ID_ROL_USUARIO_MENU = Convert.ToInt32(dr["ID_ROL_USUARIO_MENU"]);
                mi_rol_usuario_menu.ID_MENU = Convert.ToInt32(dr["ID_MENU"]);
                mi_rol_usuario_menu.ID_ROL_USUARIO = Convert.ToInt32(dr["ID_ROL_USUARIO"]);
                mi_rol_usuario_menu.NOMBRE_MENU = dr["NOMBRE_MENU"].ToString();
                mi_rol_usuario_menu.NOMBRE_ROL_USUARIO = $"{dr["NOMBRE_USUARIO"].ToString()} {dr["NOMBRE_ROL"].ToString()}";
                lista_rol_usuario_menu.Add(mi_rol_usuario_menu);
            }

            dr.Dispose();
            return View(lista_rol_usuario_menu);
        }

      

        // GET: rolUsuarioMenuController/Create
        public ActionResult Create()
        {
            var menu = new List<SelectListItem>();
            var sql = "SELECT * FROM MENU";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                menu.Add(new SelectListItem()
                {
                    Text = dr["NOMBRE"].ToString(),
                    Value = dr["ID_MENU"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.menu = menu;
            var rol_usuario = new List<SelectListItem>();
            sql = "SELECT A.ID_ROL_USUARIO, B.NOMBRE NOMBRE_USUARIO, C.NOMBRE NOMBRE_ROL FROM ROL_USUARIO A INNER JOIN USUARIO B ON A.ID_USUARIO = B.ID_USUARIO INNER JOIN ROL2 C ON C.ID_ROL2 = A.ID_ROL2";
            dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                rol_usuario.Add(new SelectListItem()
                {
                    Text =$"{dr["NOMBRE_USUARIO"].ToString()} {dr["NOMBRE_ROL"].ToString()}" ,
                    Value = dr["ID_ROL_USUARIO"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.rol_usuario = rol_usuario;
            return View();
        }

        // POST: rolUsuarioMenuController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {

                var id_menu = collection["id_menu"];
                var id_rol_usuario = collection["id_rol_usuario"];

                var sql = $"INSERT INTO ROL_USUARIO_MENU (ID_ROL_USUARIO_MENU, ID_ROL_USUARIO, ID_MENU" +
                 $") VALUES ((SELECT NVL(MAX(ID_ROL_USUARIO_MENU),0) + 1 FROM ROL_USUARIO_MENU),'{id_rol_usuario}','{id_menu}')";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));

            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }

     
        // GET: rolUsuarioMenuController/Delete/5
        public ActionResult Delete(int id)
        {
            Rol_usuario_menu mi_rol_usuario_menu = new Rol_usuario_menu();
            var sql = $"SELECT * FROM ROL_USUARIO_MENU WHERE ID_ROL_USUARIO_MENU = {id}";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                mi_rol_usuario_menu.ID_ROL_USUARIO = Convert.ToInt32(dr["ID_ROL_USUARIO"]);
                mi_rol_usuario_menu.ID_ROL_USUARIO_MENU = Convert.ToInt32(dr["ID_ROL_USUARIO_MENU"]);
                mi_rol_usuario_menu.ID_MENU = Convert.ToInt32(dr["ID_MENU"]);


            }
            dr.Dispose();
            return View(mi_rol_usuario_menu);
        }

        // POST: rolUsuarioMenuController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                var sql = $"DELETE FROM ROL_USUARIO_MENU WHERE ID_ROL_USUARIO_MENU = '{id}'";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }
    }
}
