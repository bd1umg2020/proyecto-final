﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using p_bd1_proveedores_cuentas_por_pagar.Models.Roles;

namespace p_bd1_proveedores_cuentas_por_pagar.Controllers.Roles
{
    public class rol2Controller : Controller
    {
        // GET: rol2Controller
        public ActionResult Index()
        {
            List<Rol2> lista_rol2 = new List<Rol2>();
            var sql = "SELECT * FROM ROL2 ORDER BY NOMBRE";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                Rol2 mi_rol2 = new Rol2();
                mi_rol2.ID_ROL2 = Convert.ToInt32(dr["ID_ROL2"]);
                mi_rol2.NOMBRE = dr["NOMBRE"].ToString();

                lista_rol2.Add(mi_rol2);
            }

            dr.Dispose();
            return View(lista_rol2);
        }

     

        // GET: rol2Controller/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: rol2Controller/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {

                var nommbre = collection["nombre"];
                var sql = $"INSERT INTO ROL2 (ID_ROL2, NOMBRE" +
                    $") VALUES ((SELECT NVL(MAX(ID_ROL2),0) + 1 FROM ROL2),'{nommbre}')";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }

     
        // GET: rol2Controller/Delete/5
        public ActionResult Delete(int id)
        {
            Rol2 mi_rol2 = new Rol2();
            var sql = $"SELECT * FROM ROL2 WHERE ID_ROL2 = {id}";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                mi_rol2.ID_ROL2 = Convert.ToInt32(dr["ID_ROL2"]);
                mi_rol2.NOMBRE = dr["NOMBRE"].ToString();
            }
            dr.Dispose();
            return View(mi_rol2);
        }

        // POST: rol2Controller/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                var sql = $"DELETE FROM ROL2 WHERE ID_ROL2 = '{id}'";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }
    }
}
