﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using p_bd1_proveedores_cuentas_por_pagar.Models.Roles;

namespace p_bd1_proveedores_cuentas_por_pagar.Controllers.Roles
{
    public class rolUsuarioController : Controller
    {
        // GET: rolUsuarioController
        public ActionResult Index()
        {
            List<Rol_usuario> lista_rol_usuario = new List<Rol_usuario>();
            var sql = "SELECT A.ID_ROL_USUARIO, A.ID_ROL2, A.ID_USUARIO, B.NOMBRE NOMBRE_USUARIO, C.NOMBRE NOMBRE_ROL FROM ROL_USUARIO A INNER JOIN USUARIO B ON A.ID_USUARIO = B.ID_USUARIO INNER JOIN ROL2 C ON C.ID_ROL2 = A.ID_ROL2 ORDER BY A.ID_USUARIO";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                Rol_usuario mi_rol_usuario = new Rol_usuario();
                mi_rol_usuario.ID_ROL_USUARIO = Convert.ToInt32(dr["ID_ROL_USUARIO"]);
                mi_rol_usuario.ID_ROL2 = Convert.ToInt32(dr["ID_ROL2"]);
                mi_rol_usuario.ID_USUARIO = Convert.ToInt32(dr["ID_USUARIO"]);
                mi_rol_usuario.NOMBRE_ROL = dr["NOMBRE_ROL"].ToString();
                mi_rol_usuario.NOMBRE_USUARIO = dr["NOMBRE_USUARIO"].ToString();

                lista_rol_usuario.Add(mi_rol_usuario);
            }

            dr.Dispose();
            return View(lista_rol_usuario);
        }



        // GET: rolUsuarioController/Create
        public ActionResult Create()
        {
            var usuario = new List<SelectListItem>();
            var sql = "SELECT * FROM USUARIO";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                usuario.Add(new SelectListItem()
                {
                    Text = dr["NOMBRE"].ToString(),
                    Value = dr["ID_USUARIO"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.usuario = usuario;
            var rol = new List<SelectListItem>();
            sql = "SELECT * FROM ROL2";
            dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                rol.Add(new SelectListItem()
                {
                    Text = dr["NOMBRE"].ToString(),
                    Value = dr["ID_ROL2"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.rol2 = rol;
            return View();
        }

        // POST: rolUsuarioController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {

                var id_usuario = collection["id_usuario"];
                var id_rol2 = collection["id_rol2"];

                var sql = $"INSERT INTO ROL_USUARIO (ID_ROL_USUARIO, ID_USUARIO, ID_ROL2" +
                 $") VALUES ((SELECT NVL(MAX(ID_ROL_USUARIO),0) + 1 FROM ROL_USUARIO),'{id_usuario}','{id_rol2}')";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));

            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }



        // GET: rolUsuarioController/Delete/5
        public ActionResult Delete(int id)
        {
            Rol_usuario mi_rol_usuario = new Rol_usuario();
            var sql = $"SELECT * FROM ROL_USUARIO WHERE ID_ROL_USUARIO = {id}";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                mi_rol_usuario.ID_ROL_USUARIO = Convert.ToInt32(dr["ID_ROL_USUARIO"]);
                mi_rol_usuario.ID_ROL2 = Convert.ToInt32(dr["ID_ROL2"]);
                mi_rol_usuario.ID_USUARIO = Convert.ToInt32(dr["ID_USUARIO"]);


            }
            dr.Dispose();
            return View(mi_rol_usuario);
        }

        // POST: rolUsuarioController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                var sql = $"DELETE FROM ROL_USUARIO WHERE ID_ROL_USUARIO = '{id}'";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }
    }
}
