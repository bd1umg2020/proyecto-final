﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using p_bd1_proveedores_cuentas_por_pagar.Models.Roles;

namespace p_bd1_proveedores_cuentas_por_pagar.Controllers.Roles
{
    public class usuarioController : Controller
    {
        // GET: usuarioController
        public ActionResult Index()
        {
            List<Usuario> lista_usuario = new List<Usuario>();
            var sql = "SELECT * FROM USUARIO ORDER BY NOMBRE";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                Usuario mi_usuario = new Usuario();
                mi_usuario.ID_USUARIO = Convert.ToInt32(dr["ID_USUARIO"]);
                mi_usuario.NOMBRE = dr["NOMBRE"].ToString();
                mi_usuario.CLAVE = dr["CLAVE"].ToString();

                lista_usuario.Add(mi_usuario);
            }

            dr.Dispose();
            return View(lista_usuario);
        }



        // GET: usuarioController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: usuarioController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {

                var nommbre = collection["nombre"];
                var clave = collection["clave"];
                var sql = $"INSERT INTO USUARIO (ID_USUARIO, NOMBRE, CLAVE" +
                    $") VALUES ((SELECT NVL(MAX(ID_USUARIO),0) + 1 FROM USUARIO),'{nommbre}','{clave}')";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }

      

        // GET: usuarioController/Delete/5
        public ActionResult Delete(int id)
        {
            Usuario mi_usuario = new Usuario();
            var sql = $"SELECT * FROM USUARIO WHERE ID_USUARIO = {id}";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                mi_usuario.ID_USUARIO = Convert.ToInt32(dr["ID_USUARIO"]);
                mi_usuario.NOMBRE = dr["NOMBRE"].ToString();
            }
            dr.Dispose();
            return View(mi_usuario);
        }

        // POST: usuarioController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                var sql = $"DELETE FROM USUARIO WHERE ID_USUARIO = '{id}'";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }
    }
}
