﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using p_bd1_proveedores_cuentas_por_pagar.Models;

namespace p_bd1_proveedores_cuentas_por_pagar.Controllers.Catalogos
{
    public class sucursalController : Controller
    {
        // GET: sucursalController
        public ActionResult Index()
        {
            List<Sucursal> lista_sucursales = new List<Sucursal>();
            var sql = "SELECT * FROM SUCURSAL ORDER BY NOMBRE_SUCURSAL";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                Sucursal mi_sucursal = new Sucursal();
                mi_sucursal.ID_SUCURSAL = Convert.ToInt32(dr["ID_SUCURSAL"]);
                mi_sucursal.ID_DIRECCION = Convert.ToInt32(dr["ID_DIRECCION"]);
                mi_sucursal.ID_TIPO_SUCURSAL = Convert.ToInt32(dr["ID_TIPO_SUCURSAL"]);
                mi_sucursal.NOMBRE_SUCURSAL = dr["NOMBRE_SUCURSAL"].ToString();

                lista_sucursales.Add(mi_sucursal);
            }

            dr.Dispose();
            return View(lista_sucursales);
        }


        // GET: sucursalController/Create
        public ActionResult Create()
        {
            var tipo_sucursales = new List<SelectListItem>();
            var sql = "SELECT * FROM TIPO_SUCURSAL ORDER BY NOMBRE_TIPO_SUCURSAL";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                tipo_sucursales.Add(new SelectListItem()
                {
                    Text = dr["NOMBRE_TIPO_SUCURSAL"].ToString(),
                    Value = dr["ID_TIPO_SUCURSAL"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.tipo_sucursales = tipo_sucursales;

            var direcciones = new List<SelectListItem>();
             sql = "SELECT * FROM DIRECCION ORDER BY DIRECCION";
             dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                direcciones.Add(new SelectListItem()
                {
                    Text = dr["direccion"].ToString(),
                    Value = dr["id_direccion"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.direcciones = direcciones;

            return View();
        }

        // POST: sucursalController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                var id_direccion = collection["id_direccion"];
                var id_tipo_sucursal = collection["id_tipo_sucursal"];
                var nombre_sucursal = collection["nombre_sucursal"];
                
                var sql = $"INSERT INTO SUCURSAL (ID_SUCURSAL, ID_DIRECCION, ID_TIPO_SUCURSAL, NOMBRE_SUCURSAL" +
                    $") VALUES ((SELECT NVL(MAX(ID_SUCURSAL),0) + 1 FROM SUCURSAL),'{id_direccion}','{id_tipo_sucursal}','{nombre_sucursal}')";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }


        // GET: sucursalController/Delete/5
        public ActionResult Delete(int id)
        {
            Sucursal mi_sucursal = new Sucursal();
            var sql = $"SELECT * FROM SUCURSAL WHERE ID_SUCURSAL = {id}";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                mi_sucursal.ID_SUCURSAL = Convert.ToInt32(dr["ID_SUCURSAL"]);
                mi_sucursal.ID_DIRECCION = Convert.ToInt32(dr["ID_DIRECCION"]);
                mi_sucursal.ID_TIPO_SUCURSAL = Convert.ToInt32(dr["ID_TIPO_SUCURSAL"]);
                mi_sucursal.NOMBRE_SUCURSAL = dr["NOMBRE_SUCURSAL"].ToString();
            }
            return View(mi_sucursal);
        }

        // POST: sucursalController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                var sql = $"DELETE FROM SUCURSAL WHERE ID_SUCURSAL = '{id}'";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }


        public JsonResult obtenerDireccionCompleta(int idDireccion)
        {


            direccion_compleata mi_direccion = new direccion_compleata();
            var sql = $"SELECT * FROM DIRECCION A INNER JOIN ZONA_SECTOR_ B ON A.ID_ZONA = B.ID_ZONA INNER JOIN MUNICIPIO_CIUDAD_ C ON C.ID_MUNICIPIO = B.ID_MUNICIPIO " +
                $"INNER JOIN DEPARTAMENTO_ESTADO_ D ON D.ID_DEPARTAMENTO = C.ID_DEPARTAMENTO INNER JOIN PAIS E ON E.ID_PAIS = D.ID_PAIS WHERE ID_DIRECCION = '{idDireccion}'";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                mi_direccion.zona = dr["nombre_zona"].ToString();
                mi_direccion.municipio = dr["nombre_municipio"].ToString();
                mi_direccion.departamento = dr["nombre_departamento"].ToString();
                mi_direccion.pais = dr["nombre_pais"].ToString();
            }

            dr.Dispose();

            return Json(mi_direccion);

        }
        public class direccion_compleata
        {
            public string zona { get; set; }
            public string municipio { get; set; }
            public string departamento { get; set; }
            public string pais { get; set; }
        };

    }
}
