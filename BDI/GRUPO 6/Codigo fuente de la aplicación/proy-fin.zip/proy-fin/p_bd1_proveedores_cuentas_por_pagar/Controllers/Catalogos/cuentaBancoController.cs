﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using p_bd1_proveedores_cuentas_por_pagar.Models;

namespace p_bd1_proveedores_cuentas_por_pagar.Controllers.Catalogos
{
    public class cuentaBancoController : Controller
    {
        // GET: cuentaBancoController
        public ActionResult Index()
        {
            List<Cuenta_banco> lista_cuenta_banco = new List<Cuenta_banco>();
            var sql = "SELECT * FROM CUENTA_BANCO ORDER BY NO_CUENTA";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                Cuenta_banco mi_cuenta_banco = new Cuenta_banco();
                mi_cuenta_banco.ID_CUENTA_BANCO = Convert.ToInt32(dr["ID_CUENTA_BANCO"]);
                mi_cuenta_banco.ID_TIPO_CUENTA = Convert.ToInt32(dr["ID_TIPO_CUENTA"]);
                mi_cuenta_banco.ID_BANCO = Convert.ToInt32(dr["ID_BANCO"]);
                mi_cuenta_banco.NO_CUENTA = Convert.ToInt32(dr["NO_CUENTA"]);
                mi_cuenta_banco.SALDO = Convert.ToDouble(dr["SALDO"]);


                lista_cuenta_banco.Add(mi_cuenta_banco);
            }

            dr.Dispose();
            return View(lista_cuenta_banco);
        }

   
        // GET: cuentaBancoController/Create
        public ActionResult Create()
        {
            var tipo_cuenta = new List<SelectListItem>();
            var sql = "SELECT * FROM TIPO_CUENTA ORDER BY TIPO_CUENTA";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                tipo_cuenta.Add(new SelectListItem()
                {
                    Text = dr["TIPO_CUENTA"].ToString(),
                    Value = dr["ID_TIPO_CUENTA"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.tipo_cuenta = tipo_cuenta;

            var banco = new List<SelectListItem>();
            sql = "SELECT * FROM BANCO ORDER BY NOMBRE_BANCO";
            dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                banco.Add(new SelectListItem()
                {
                    Text = dr["NOMBRE_BANCO"].ToString(),
                    Value = dr["ID_BANCO"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.banco = banco;
            return View();
        }

        // POST: cuentaBancoController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                var id_tipo_cuenta = collection["id_tipo_cuenta"];
                var id_banco = collection["id_banco"];
                var no_cuenta = collection["no_cuenta"];
                var saldo = collection["saldo"];
                var sql = $"INSERT INTO CUENTA_BANCO (ID_CUENTA_BANCO, ID_TIPO_CUENTA, ID_BANCO, NO_CUENTA, SALDO" +
                    $") VALUES ((SELECT NVL(MAX(ID_CUENTA_BANCO),0) + 1 FROM CUENTA_BANCO),'{id_tipo_cuenta}','{id_banco}','{no_cuenta}','{saldo}')";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }

      

        // GET: cuentaBancoController/Delete/5
        public ActionResult Delete(int id)
        {
            Cuenta_banco mi_cuenta_banco = new Cuenta_banco();
            var sql = $"SELECT * FROM CUENTA_BANCO WHERE ID_CUENTA_BANCO = {id}";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                mi_cuenta_banco.ID_CUENTA_BANCO = Convert.ToInt32(dr["ID_CUENTA_BANCO"]);
                mi_cuenta_banco.ID_TIPO_CUENTA = Convert.ToInt32(dr["ID_TIPO_CUENTA"]);
                mi_cuenta_banco.ID_BANCO = Convert.ToInt32(dr["ID_BANCO"]);
                mi_cuenta_banco.NO_CUENTA = Convert.ToInt32(dr["NO_CUENTA"]);
                mi_cuenta_banco.SALDO = Convert.ToInt32(dr["SALDO"]);
            }
            return View(mi_cuenta_banco);
        }

        // POST: cuentaBancoController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                var sql = $"DELETE FROM CUENTA_BANCO WHERE ID_CUENTA_BANCO = '{id}'";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }
    }
}
