﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using p_bd1_proveedores_cuentas_por_pagar.Models;

namespace p_bd1_proveedores_cuentas_por_pagar.Controllers.Catalogos
{
    public class productoController : Controller
    {
        // GET: productoController
        public ActionResult Index()
        {
            List<Producto> lista_productos = new List<Producto>();
            var sql = "SELECT * FROM PRODUCTO ORDER BY NOMBRE_PRODUCTO";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                Producto mi_producto = new Producto();
                mi_producto.ID_PRODUCTO = Convert.ToInt32(dr["ID_PRODUCTO"]);
                mi_producto.NOMBRE_PRODUCTO = dr["NOMBRE_PRODUCTO"].ToString();
                lista_productos.Add(mi_producto);
            }

            dr.Dispose();
            return View(lista_productos);
        }

       

        // GET: productoController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: productoController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                var nombre_producto = collection["nombre_producto"];
                var sql = $"INSERT INTO PRODUCTO (ID_PRODUCTO, NOMBRE_PRODUCTO) VALUES ((SELECT NVL(MAX(ID_PRODUCTO),0) + 1 FROM PRODUCTO)," +
                    $"'{nombre_producto.ToString().ToUpper().Trim()}')";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }


        // GET: productoController/Delete/5
        public ActionResult Delete(int id)
        {
            Producto mi_producto = new Producto();
            var sql = $"SELECT * FROM PRODUCTO WHERE ID_PRODUCTO = {id}";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                mi_producto.ID_PRODUCTO = Convert.ToInt32(dr["ID_PRODUCTO"]);
                mi_producto.NOMBRE_PRODUCTO = dr["NOMBRE_PRODUCTO"].ToString();
            }
            dr.Dispose();
            return View(mi_producto);
        }

        // POST: productoController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                var sql = $"DELETE FROM PRODUCTO WHERE ID_PRODUCTO = '{id}'";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }
    }
}
