﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using p_bd1_proveedores_cuentas_por_pagar.Models;

namespace p_bd1_proveedores_cuentas_por_pagar.Controllers.Catalogos
{
    public class bancoController : Controller
    {
        // GET: bancoController
        public ActionResult Index()
        {
            List<Banco> lista_banco = new List<Banco>();
            var sql = "SELECT * FROM BANCO ORDER BY NOMBRE_BANCO";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                Banco mi_banco = new Banco();
                mi_banco.ID_BANCO = Convert.ToInt32(dr["ID_BANCO"]);
                mi_banco.NOMBRE_BANCO = dr["NOMBRE_BANCO"].ToString();

                lista_banco.Add(mi_banco);
            }

            dr.Dispose();
            return View(lista_banco);
        }


        // GET: bancoController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: bancoController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {

                var nombre_banco = collection["nombre_banco"];


                var sql = $"INSERT INTO BANCO (ID_BANCO, NOMBRE_BANCO" +
                    $") VALUES ((SELECT NVL(MAX(ID_BANCO),0) + 1 FROM BANCO),'{nombre_banco}')";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }



        // GET: bancoController/Delete/5
        public ActionResult Delete(int id)
        {
            Banco mi_banco = new Banco();
            var sql = $"SELECT * FROM BANCO WHERE ID_BANCO = {id}";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                mi_banco.ID_BANCO = Convert.ToInt32(dr["ID_BANCO"]);
                mi_banco.NOMBRE_BANCO = dr["NOMBRE_BANCO"].ToString();

            }
            dr.Dispose();
            return View(mi_banco);
        }

        // POST: bancoController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                var sql = $"DELETE FROM BANCO WHERE ID_BANCO = '{id}'";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }
    }
}
