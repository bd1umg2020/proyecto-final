﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using p_bd1_proveedores_cuentas_por_pagar.Models;

namespace p_bd1_proveedores_cuentas_por_pagar.Controllers
{
    public class puestoEmpleadoController : Controller
    {
        // GET: puestoEmpleadoController
        public ActionResult Index(int id)
        {

            List<Puesto_empleado> lista_puesto_empleado = new List<Puesto_empleado>();
            var sql = $"SELECT * FROM PUESTO_EMPLEADO A INNER JOIN PUESTO B ON B.ID_PUESTO = A.ID_PUESTO INNER JOIN EMPLEADO C ON C.ID_EMPLEADO = A.ID_EMPLEADO " +
                $"INNER JOIN PERSONA D ON D.ID_PERSONA = C.ID_PERSONA WHERE A.ID_EMPLEADO = {id} ORDER BY FECHA_INICIO DESC";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                Puesto_empleado mi_puesto_empleado = new Puesto_empleado();
                mi_puesto_empleado.ID_PUESTO_EMPLEADO = Convert.ToInt32(dr["ID_PUESTO_EMPLEADO"]);
                mi_puesto_empleado.ID_PUESTO = Convert.ToInt32(dr["ID_PUESTO"]);
                mi_puesto_empleado.ID_EMPLEADO = Convert.ToInt32(dr["ID_EMPLEADO"]);
                mi_puesto_empleado.FECHA_INICIO = Convert.ToDateTime(dr["FECHA_INICIO"]);
                if (dr["FECHA_FIN"] != DBNull.Value)
                {
                    mi_puesto_empleado.FECHA_FIN = Convert.ToDateTime(dr["FECHA_FIN"]);
                }
                mi_puesto_empleado.NOMBRE_PERSONA = dr["NOMBRE_PERSONA"].ToString();
                mi_puesto_empleado.NOMBRE_PUESTO = dr["NOMBRE_PUESTO"].ToString();
                lista_puesto_empleado.Add(mi_puesto_empleado);
            }
            dr.Dispose();
            ViewBag.idEmpleado = id;
            return View(lista_puesto_empleado);
        }


        // GET: puestoEmpleadoController/Create
        public ActionResult Create(int id)
        {

            var puesto = new List<SelectListItem>();
            var sql = "SELECT * FROM PUESTO ORDER BY NOMBRE_PUESTO";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                puesto.Add(new SelectListItem()
                {
                    Text = dr["nombre_puesto"].ToString(),
                    Value = dr["id_puesto"].ToString()
                });
            }
            dr.Dispose();
            ViewBag.puesto = puesto;
            ViewBag.idEmpleado = id;
            return View();
        }

        // POST: puestoEmpleadoController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                var id_puesto = collection["id_puesto"].ToString();
                var id_empleado = collection["id_empleado"].ToString();
                var fecha_inicio = Convert.ToDateTime(collection["fecha_inicio"]).ToString("dd/MM/yyyy");
                var sql = $"UPDATE PUESTO_EMPLEADO SET FECHA_FIN = SYSDATE WHERE FECHA_FIN IS NULL AND ID_EMPLEADO = {id_empleado}";
                ora_conn.ExecuteNonQuery(sql);
                sql = $"INSERT INTO PUESTO_EMPLEADO (ID_PUESTO_EMPLEADO, ID_PUESTO, ID_EMPLEADO, FECHA_INICIO) VALUES ((SELECT NVL(MAX(ID_PUESTO_EMPLEADO),0) + 1 FROM PUESTO_EMPLEADO)," +
                    $"'{id_puesto}','{id_empleado}', '{fecha_inicio}')";
                ora_conn.ExecuteNonQuery(sql);
                return RedirectToAction(nameof(Index),new { @id = id_empleado });
            }
            catch (Exception ex)
            {
                ViewBag.error = ex.Message;
                return View();
            }
        }

    }
}
