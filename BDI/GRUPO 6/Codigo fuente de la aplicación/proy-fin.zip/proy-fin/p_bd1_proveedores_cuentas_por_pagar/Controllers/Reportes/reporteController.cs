﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using p_bd1_proveedores_cuentas_por_pagar.Controllers.Operaciones;
using p_bd1_proveedores_cuentas_por_pagar.Models;
using p_bd1_proveedores_cuentas_por_pagar.Models.Reportes;

namespace p_bd1_proveedores_cuentas_por_pagar.Controllers.Reportes
{
    public class reporteController : Controller
    {


        public ActionResult Index()
        {
            return View();
        }
        public ActionResult estadoCuentaBanco(int id)
        {
            List<estadoCuentaBanco> lista_estado_cuenta_banco = new List<estadoCuentaBanco>();
            var sql = $"SELECT PC.ID_PAGAR_CUENTA, PC.MONTO, FP.NOMBRE_FORMA_PAGO, MB.SALDO_ANTERIOR, MB.SALDO_NUEVO, CB.NO_CUENTA, B.NOMBRE_BANCO " +
                $"FROM PAGAR_CUENTA PC " +
                $"JOIN FORMA_PAGO FP ON PC.ID_FORMA_PAGO = FP.ID_FORMA_PAGO " +
                $"JOIN MOV_BANCO MB ON PC.ID_PAGAR_CUENTA = MB.ID_PAGAR_CUENTA " +
                $"JOIN CUENTA_BANCO CB ON PC.ID_CUENTA_BANCO = CB.ID_CUENTA_BANCO " +
                $"JOIN BANCO B ON CB.ID_BANCO = B.ID_BANCO " +
                $"WHERE PC.ID_CUENTA_BANCO = {id.ToString()} ORDER BY ID_PAGAR_CUENTA";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                estadoCuentaBanco mi_estado_cuenta_banco = new estadoCuentaBanco();
                mi_estado_cuenta_banco.ID_PAGAR_CUENTA = Convert.ToInt32(dr["ID_PAGAR_CUENTA"]);
                mi_estado_cuenta_banco.MONTO = Convert.ToDouble(dr["MONTO"]);
                mi_estado_cuenta_banco.NOMBRE_FORMA_PAGO = dr["NOMBRE_FORMA_PAGO"].ToString();
                mi_estado_cuenta_banco.SALDO_ANTERIOR = Convert.ToDouble(dr["SALDO_ANTERIOR"]);
                mi_estado_cuenta_banco.SALDO_NUEVO = Convert.ToDouble(dr["SALDO_NUEVO"]);
                mi_estado_cuenta_banco.NO_CUENTA = Convert.ToInt32(dr["NO_CUENTA"]);
                mi_estado_cuenta_banco.NOMBRE_BANCO = dr["NOMBRE_BANCO"].ToString();

                lista_estado_cuenta_banco.Add(mi_estado_cuenta_banco);
            }

            dr.Dispose();
            return View(lista_estado_cuenta_banco);
        }

        public ActionResult existenciaSucursal(int id)
        {
            List<existenciaSucursal> lista_existencia_sucursal = new List<existenciaSucursal>();
            var sql = $"SELECT  S.NOMBRE_SUCURSAL, ES.EXISTENCIAS, P.NOMBRE_PRODUCTO " +
                $"FROM EXISTENCIAS_SUCURSAL ES " +
                $"JOIN SUCURSAL S ON  ES.ID_SUCURSAL = S.ID_SUCURSAL " +
                $"JOIN PRODUCTO P ON  ES.ID_PRODUCTO = P.ID_PRODUCTO " +
                $"WHERE S.ID_SUCURSAL = {id}";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                existenciaSucursal mi_existencia_sucursal = new existenciaSucursal();
                mi_existencia_sucursal.NOMBRE_SUCURSAL = dr["NOMBRE_SUCURSAL"].ToString();
                mi_existencia_sucursal.NOMBRE_PRODUCTO = dr["NOMBRE_PRODUCTO"].ToString();
                mi_existencia_sucursal.EXISTENCIAS = Convert.ToInt32(dr["EXISTENCIAS"]);
                lista_existencia_sucursal.Add(mi_existencia_sucursal);
            }

            dr.Dispose();
            return View(lista_existencia_sucursal);
        }

        public ActionResult facturaProveedor(int id)
        {
            List<facturaProveedor_> lista_factura_proveedor = new List<facturaProveedor_>();
            var sql = $"SELECT  FP.NUMERO_FACTURA, P.NOMBRE_PROVEEDOR, P.NIT_PROVEEDOR,  OC.ID_ORDEN_COMPRA, FP.FECHA, FP.MONTO, STATUS_APROBACION, STATUS_RECEPCION " +
                $"FROM FACTURA_PROVEEDOR FP " +
                $"JOIN ORDEN_COMPRA OC ON FP.ID_ORDEN_COMPRA = OC.ID_ORDEN_COMPRA " +
                $"JOIN PROVEEDOR P ON OC.ID_PROVEEDOR = P.ID_PROVEEDOR " +
                $"WHERE P.ID_PROVEEDOR = {id}";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                facturaProveedor_ mi_factura_proveedor = new facturaProveedor_();
                mi_factura_proveedor.NUMERO_FACTURA = Convert.ToInt32(dr["NUMERO_FACTURA"]);
                mi_factura_proveedor.NOMBRE_PROVEEDOR = dr["NOMBRE_PROVEEDOR"].ToString();
                mi_factura_proveedor.NIT_PROVEEDOR = dr["NIT_PROVEEDOR"].ToString();
                mi_factura_proveedor.ID_ORDEN_COMPRA = Convert.ToInt32(dr["ID_ORDEN_COMPRA"]);
                mi_factura_proveedor.FECHA_FACTURA = Convert.ToDateTime(dr["FECHA"]);
                mi_factura_proveedor.MONTO = Convert.ToDouble(dr["MONTO"]);
                lista_factura_proveedor.Add(mi_factura_proveedor);
            }

            dr.Dispose();
            return View(lista_factura_proveedor);
        }


        public ActionResult ListaBancos()
        {
            List<Banco> lista_banco = new List<Banco>();
            var sql = "SELECT * FROM BANCO ORDER BY NOMBRE_BANCO";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                Banco mi_banco = new Banco();
                mi_banco.ID_BANCO = Convert.ToInt32(dr["ID_BANCO"]);
                mi_banco.NOMBRE_BANCO = dr["NOMBRE_BANCO"].ToString();

                lista_banco.Add(mi_banco);
            }

            dr.Dispose();
            return View(lista_banco);
        }

        public ActionResult ListaSucursales()
        {
            List<Sucursal> lista_sucursal = new List<Sucursal>();
            var sql = "SELECT * FROM SUCURSAL ORDER BY NOMBRE_SUCURSAL";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                Sucursal mi_sucursal = new Sucursal();
                mi_sucursal.ID_SUCURSAL = Convert.ToInt32(dr["ID_SUCURSAL"]);
                mi_sucursal.NOMBRE_SUCURSAL = dr["NOMBRE_SUCURSAL"].ToString();

                lista_sucursal.Add(mi_sucursal);
            }

            dr.Dispose();
            return View(lista_sucursal);
        }

        public ActionResult ListaProveedores()
        {
            List<Proveedor> lista_proveedor = new List<Proveedor>();
            var sql = "SELECT * FROM PROVEEDOR ORDER BY NOMBRE_PROVEEDOR";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                Proveedor mi_proveedor = new Proveedor();
                mi_proveedor.ID_PROVEEDOR = Convert.ToInt32(dr["ID_PROVEEDOR"]);
                mi_proveedor.NOMBRE_PROVEEDOR = dr["NOMBRE_PROVEEDOR"].ToString();

                lista_proveedor.Add(mi_proveedor);
            }

            dr.Dispose();
            return View(lista_proveedor);
        }

        public ActionResult ListaProductos()
        {
            List<compraProducto> lista_compra_producto = new List<compraProducto>();
            var sql = $"SELECT  P.NOMBRE_PRODUCTO, SUM(DC.CANTIDAD) CANTIDAD " +
                $"FROM DETALLE_COMPRA DC " +
                $"JOIN PRODUCTO P ON DC.ID_PRODUCTO = P.ID_PRODUCTO " +
                $"GROUP BY P.NOMBRE_PRODUCTO";
            var dr = ora_conn.ExecuteReader(sql);
            while (dr.Read())
            {
                compraProducto mi_compra_producto = new compraProducto();
                mi_compra_producto.NOMBRE_PRODUCTO = dr["NOMBRE_PRODUCTO"].ToString();
                mi_compra_producto.CANTIDAD = Convert.ToInt32(dr["CANTIDAD"]);

                lista_compra_producto.Add(mi_compra_producto);
            }

            dr.Dispose();
            return View(lista_compra_producto);
        }

    }
}
